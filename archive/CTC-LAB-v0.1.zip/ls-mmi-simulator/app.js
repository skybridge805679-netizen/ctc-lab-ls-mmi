'use strict';
const $=id=>document.getElementById(id);
const C=window.SimCore;
let state=C.initial(),paused=false,practice='guided',activeTask=null,taskIndex=0,taskStart=0,toastTimer,dialogAction=null;
let completed=[];try{completed=JSON.parse(localStorage.getItem('ctclab-completed')||'[]');if(!Array.isArray(completed))completed=[];}catch{}
const tasks=[
 {title:'LS에서 CCM 전환',desc:'LS의 역모드를 CCM으로 바꾸고, MMI에서도 같은 상태인지 확인하세요.',hint:'LS 상단 CCM → 확인 창에서 예. 화면 아래 역 제어모드와 MMI 상태가 함께 바뀝니다.',source:'p.14–15',check:e=>e.some(x=>x.type==='mode'&&x.source==='LS'&&x.value==='CCM')&&state.mode==='CCM'},
 {title:'MMI에서 모드 전환',desc:'MMI 현장설비제어를 이용해 AUTO에서 CCM으로 전환하세요.',hint:'제어종류: 역제어모드 설정 → CCM → 확인 · 명령 실행.',source:'p.16–17',check:e=>e.some(x=>x.type==='mode'&&x.source==='MMI'&&x.value==='CCM')&&state.mode==='CCM'},
 {title:'LS에서 진로 설정',desc:'CCM 전환 후 LS 신호기 1A에서 1A-1T 진로를 설정하세요.',hint:'CCM → LS의 1A 신호기 또는 이름 클릭 → 1A-1T 선택 → 예.',source:'p.4–5 · 배선은 훈련 모형',check:e=>e.some(x=>x.type==='route'&&x.source==='LS'&&x.id==='1A-1T')&&state.routes['1A-1T']?.status==='SET'},
 {title:'MMI에서 진로 설정',desc:'CCM 전환 후 MMI에서 3A-B070T 진로를 설정하세요.',hint:'진로제어 → 신호기 3A → 3A-B070T → 설정 → 확인.',source:'p.6–7',check:e=>e.some(x=>x.type==='route'&&x.source==='MMI'&&x.id==='3A-B070T')&&state.routes['3A-B070T']?.status==='SET'},
 {title:'신호 정지와 해정 대기',desc:'설정된 1A 신호를 LS에서 정지시킨 후 진로 해정이 끝날 때까지 확인하세요.',hint:'LS 1A 클릭 → 예. 황색 대기 표시를 확인하고 가상시간 30초가 지난 뒤 해정 여부를 확인하세요. +10초 사용 가능.',source:'p.7–8 · 30초는 훈련 설정',setup:s=>{s.mode='CCM';C.dispatch(s,{type:'route',id:'1A-1T',source:'초기 조건'});},check:e=>e.some(x=>x.type==='stop'&&x.source==='LS'&&x.signal==='1A')&&!state.routes['1A-1T']&&state.signals['1A']==='STOP'},
 {title:'전환기 취소와 실행',desc:'LS 21 전환기 조작에서 먼저 취소한 뒤, 다시 실행해 반위로 바꾸세요.',hint:'CCM → 21 전환기 이름 클릭 → 아니오. 다시 클릭 → 예. MMI 전환기 상태도 확인하세요.',source:'p.11–13',check:e=>{const a=e.findIndex(x=>x.type==='cancel'&&x.source==='LS'&&x.target==='point');return a>=0&&e.slice(a+1).some(x=>x.type==='point'&&x.source==='LS'&&x.id==='21'&&x.value==='R')&&state.points['21']==='R';}},
 {title:'LOCAL 현장 인계',desc:'LOCAL 전환 요청을 현장에서 거절한 뒤, 다시 요청하여 수락하세요.',hint:'LOCAL → 예 → 현장 거절. 다시 LOCAL → 예 → 현장 수락. 요청 중에는 기존 모드가 유지됩니다.',source:'p.15',check:e=>{const a=e.findIndex(x=>x.type==='handover'&&!x.accept);return a>=0&&e.slice(a+1).some(x=>x.type==='handover'&&x.accept)&&state.mode==='LOCAL';}},
 {title:'베이스스캔 범위 비교',desc:'LS에서 현재역 스캔을 실행하고, MMI에서 전체 제어역 스캔을 실행하세요.',hint:'선형 화면 우클릭 → 현재역 베이스스캔. MMI 베이스스캔 → 전체 제어역 → 확인.',source:'p.8–10',check:e=>e.some(x=>x.type==='scan'&&x.source==='LS'&&x.scope==='current')&&e.some(x=>x.type==='scan'&&x.source==='MMI'&&x.scope==='all')}
];
const escapeHTML=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const time=t=>`${Math.floor(t/60).toString().padStart(2,'0')}:${(t%60).toString().padStart(2,'0')}`;
function toast(message,error=false){$('toast').textContent=message;$('toast').className='show'+(error?' error':'');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').className='',4000);}
function run(a){const r=C.dispatch(state,a);render();if(a.type!=='tick')toast(r.message,!r.ok);return r;}
function trackColor(track){if(state.occupied.includes(track))return '#ff6d65';const found=Object.entries(state.routes).filter(([id])=>C.routes[id].tracks.includes(track));return found.some(([,r])=>r.status==='SET')?'#42eb89':found.length?'#edc65e':'#e2e8e1';}
function drawTracks(){const paths={W1:'M45 125H310',W2:'M45 240H310','1T':'M310 125H720','2T':'M310 240H720',E2:'M720 240H960'};
 let svg='<text x="47" y="76" class="track-hint">종각 방면</text><text x="873" y="76" class="track-hint">서울 방면</text><path d="M45 125H960M45 240H960" stroke="#354541" stroke-width="14" fill="none"/>';
 for(const [id,d] of Object.entries(paths))svg+=`<path d="${d}" stroke="${trackColor(id)}" stroke-width="5" fill="none"/><text x="${id==='W1'||id==='W2'?180:id==='E2'?850:515}" y="${id==='W1'||id==='1T'?149:265}" fill="#c8d2cb" font-size="11">${id}</text>`;
 svg+=`<path d="M310 125L395 240M635 125L720 240" stroke="#8f9d94" stroke-width="5"/><path d="M310 ${state.points['21']==='N'?125:125}l${state.points['21']==='N'?'45 0':'33 45'}M720 240l${state.points['51']==='N'?'45 0':'-33 -45'}" stroke="#fff5b7" stroke-width="6"/><rect x="470" y="168" width="150" height="28" fill="#d2a944" opacity=".85" rx="2"/><text x="545" y="186" text-anchor="middle" fill="#fff9da" font-size="10">지하서울 승강장</text>`;
 const signals=[['1A',265,125],['2A',780,240],['3A',425,125],['4A',675,240]];
 for(const [id,x,y] of signals)svg+=`<g class="clickable" data-signal="${id}" role="button" tabindex="0" aria-label="${id} 신호기"><rect x="${x-28}" y="${y-46}" width="56" height="63" fill="transparent"/><path d="M${x} ${y}v-20h18" stroke="#26372e" stroke-width="3"/><rect x="${x+6}" y="${y-30}" width="32" height="16" rx="8" fill="#1c2822"/><circle cx="${x+15}" cy="${y-22}" r="4" fill="${state.signals[id]==='GO'?'#35e780':'#fc625c'}"/><circle cx="${x+29}" cy="${y-22}" r="3" fill="#526153"/><text class="hitlabel" x="${x}" y="${y-38}" text-anchor="middle" fill="#f2f6ed" font-size="13">${id}</text></g>`;
 for(const [id,x,y] of [['21',335,190],['51',699,190]])svg+=`<g class="clickable" data-point="${id}" tabindex="0" role="button" aria-label="${id} 선로전환기"><rect x="${x-30}" y="${y-18}" width="60" height="35" fill="#43534a" rx="3"/><text class="hitlabel" x="${x}" y="${y+4}" text-anchor="middle" fill="#f4f5d9" font-size="13">${id} ${state.points[id]==='N'?'정':'반'}</text></g>`;
 const pending=Object.entries(state.routes).filter(([,r])=>r.status==='RELEASING');if(pending.length)svg+=`<text x="500" y="315" text-anchor="middle" fill="#ffe8a2" font-size="13">해정 대기 · ${pending.map(([id,r])=>id+' '+Math.max(0,r.until-state.clock)+'초').join(' / ')}</text>`;
 $('trackSvg').innerHTML=svg;
}
function render(){
 $('clock').textContent=time(state.clock);document.querySelectorAll('[data-mode]').forEach(b=>{b.classList.toggle('current',b.dataset.mode===state.mode);b.setAttribute('aria-pressed',String(b.dataset.mode===state.mode));});
 $('stateMode').textContent=state.mode;$('stateOwner').textContent=state.mode==='LOCAL'?'현장역':'관제실';$('stateRoutes').textContent=Object.values(state.routes).filter(r=>r.status==='SET').length+' / '+Object.values(state.routes).filter(r=>r.status==='RELEASING').length;$('stateScan').textContent=state.clock<state.scanUntil?'재수신 완료':'정상';
 $('lsStatus').textContent=state.clock<state.scanUntil?'베이스스캔 · 가상 현장 상태 재수신 완료':'우클릭으로 베이스스캔 메뉴 열기';
 $('mmiState').textContent=`현재 ${state.mode} · 21: ${state.points['21']==='N'?'정위':'반위'} / 51: ${state.points['51']==='N'?'정위':'반위'}`;
 $('handoverBar').hidden=!state.pending;if(state.pending)$('handoverBar').innerHTML=`<span>${state.pending} 전환 요청 · 가상 현장 응답 대기</span><button data-handover="yes">현장 수락</button><button data-handover="no">현장 거절</button>`;
 drawTracks();renderLogs();$('completedCount').textContent=`${completed.length} / 8 완료`;
}
function renderLogs(){$('logCount').textContent=state.logs.length+' events';$('logList').innerHTML=state.logs.length?state.logs.slice(0,100).map(l=>`<div class="log-row"><span class="log-time">${time(l.time)}</span><div><p>${escapeHTML(l.message)}</p><div class="log-meta">${escapeHTML(l.source)} <span class="${l.result==='완료'?'result-ok':'result-bad'}">· ${l.result}</span></div></div></div>`).join(''):'<p class="empty">첫 조작을 기다리고 있습니다.</p>';}
function fields(){const control=$('controlSelect').value;let html='';
 if(control==='mode')html='<span class="field-label">제어모드</span><div class="radio-row">'+['AUTO','CCM','LOCAL'].map((v,i)=>`<label><input type="radio" name="mmiMode" value="${v}" ${i===1?'checked':''}>${v}</label>`).join('')+'</div>';
 if(control==='route')html='<label class="field-label" for="mmiSignal">신호기</label><select id="mmiSignal">'+Object.keys(state.signals).map(id=>`<option>${id}</option>`).join('')+'</select><label class="field-label" for="mmiRoute">진로</label><select id="mmiRoute"></select><div class="radio-row"><label><input name="routeAction" type="radio" value="set" checked>설정</label><label><input name="routeAction" type="radio" value="stop">해정 요청</label></div>';
 if(control==='point')html='<label class="field-label" for="mmiPoint">선로전환기</label><select id="mmiPoint"><option>21</option><option>51</option></select><div class="radio-row"><label><input type="radio" name="mmiPointState" value="N" checked>정위</label><label><input type="radio" name="mmiPointState" value="R">반위</label></div>';
 if(control==='scan')html='<span class="field-label">제어구분</span><div class="radio-row"><label><input type="radio" name="mmiScope" value="current" checked>선택역</label><label><input type="radio" name="mmiScope" value="all">전체 제어역</label></div>';
 $('mmiFields').innerHTML=html;if(control==='route'){routeOptions();$('mmiSignal').onchange=routeOptions;}
}
function routeOptions(){$('mmiRoute').innerHTML=Object.entries(C.routes).filter(([,v])=>v.signal===$('mmiSignal').value).map(([id])=>`<option>${id}</option>`).join('');}
function openAction(title,body,action){$('dialogTitle').textContent=title;$('dialogBody').innerHTML=body;dialogAction=action;$('actionDialog').returnValue='';$('dialogConfirm').textContent='예 · 실행';$('actionDialog').showModal();}
function signalAction(id){if(state.signals[id]==='GO'){openAction(id+' 신호기 정지','신호기를 정지시키고 진로 해정을 요청합니다.<br>이 모형에서는 30초 해정 대기가 적용됩니다.',{type:'stop',signal:id,source:'LS'});}else{openAction(id+' 진로제어','설정할 진로를 선택하세요.<select id="lsRouteSelect" aria-label="LS 진로 선택">'+Object.entries(C.routes).filter(([,r])=>r.signal===id).map(([key])=>`<option>${key}</option>`).join('')+'</select>',()=>({type:'route',id:$('lsRouteSelect').value,source:'LS'}));}}
function pointAction(id){const next=state.points[id]==='N'?'R':'N';openAction(id+' 선로전환기 제어',`현재 <b>${state.points[id]==='N'?'정위':'반위'}</b> → <b>${next==='N'?'정위':'반위'}</b>로 전환하시겠습니까?`,{type:'point',id,value:next,source:'LS'});}
function taskView(){const task=tasks[taskIndex],started=activeTask===taskIndex;$('taskSelect').value=taskIndex;$('taskBody').innerHTML=practice==='free'?'<div class="task-card"><div class="task-heading"><span class="task-num">∞</span><h3>자유롭게 설비를 조작하세요</h3></div><p>점유 조건을 추가하면 진로와 전환기 제어의 거부 경로를 확인할 수 있습니다.</p><div class="occupied-controls">'+['1T','2T'].map(id=>`<button data-occupy="${id}">${id} 점유 전환</button>`).join('')+'</div><p>자동 열차 이동은 다음 단계에서 구현합니다.</p></div>':`<div class="task-card"><div class="task-heading"><span class="task-num">${String(taskIndex+1).padStart(2,'0')}</span><h3>${task.title}</h3><span class="task-badge">${completed.includes(taskIndex)?'✓ 달성':started?'진행 중':'시작 전'}</span></div><p>${task.desc}</p>${practice==='guided'?`<p class="task-hint">↳ ${task.hint}</p>`:''}<p>근거: CTC 운영 매뉴얼 ${task.source}</p><p id="taskResult"></p></div>`;$('startTask').hidden=practice==='free';$('checkTask').hidden=practice==='free';$('nextTask').hidden=practice==='free';}
function startTask(){if(state.logs.length && !confirm('현재 실습 상태와 조작 기록을 초기화하고 선택한 과제를 시작할까요?'))return;state=C.initial();const t=tasks[taskIndex];if(t.setup)t.setup(state);taskStart=state.events.length;activeTask=taskIndex;paused=false;$('pauseBtn').textContent='Ⅱ 일시정지';$('controlSelect').value='mode';fields();render();taskView();toast('과제 시작 · '+t.title);}
$('taskSelect').innerHTML=tasks.map((t,i)=>`<option value="${i}">${String(i+1).padStart(2,'0')} · ${t.title}</option>`).join('');
$('taskSelect').onchange=e=>{taskIndex=Number(e.target.value);taskView();};
document.querySelectorAll('[data-practice]').forEach(b=>b.onclick=()=>{practice=b.dataset.practice;document.querySelectorAll('[data-practice]').forEach(x=>x.classList.toggle('selected',x===b));taskView();});
document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>openAction(b.dataset.mode+' 모드 전환',`역제어모드를 <b>${b.dataset.mode}</b>로 전환하시겠습니까?${b.dataset.mode==='LOCAL'||state.mode==='LOCAL'?'<br>현장 응답 후 제어권이 변경됩니다.':''}`,{type:'mode',value:b.dataset.mode,source:'LS'}));
$('trackSvg').addEventListener('click',e=>{const s=e.target.closest('[data-signal]'),p=e.target.closest('[data-point]');if(s)signalAction(s.dataset.signal);if(p)pointAction(p.dataset.point);});
$('trackSvg').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.target.dispatchEvent(new MouseEvent('click',{bubbles:true}));}});
$('lsDisplay').oncontextmenu=e=>{e.preventDefault();openAction('ベ이스스캔','가상 현장의 상태정보를 다시 수신합니다. 설비 상태를 초기화하지 않습니다.<select id="lsScope" aria-label="베이스스캔 범위"><option value="current">현재역 베이스스캔</option><option value="all">전체역 베이스스캔</option></select>',()=>({type:'scan',scope:$('lsScope').value,source:'LS'}));};
$('actionDialog').addEventListener('close',()=>{if(!dialogAction)return;const a=typeof dialogAction==='function'?dialogAction():dialogAction;dialogAction=null;if($('actionDialog').returnValue==='confirm')run(a);else run({type:'cancel',target:a.type,source:'LS'});});
$('handoverBar').onclick=e=>{const b=e.target.closest('[data-handover]');if(b)run({type:'handover',accept:b.dataset.handover==='yes',source:'현장'});};
$('controlSelect').onchange=fields;
$('mmiApply').onclick=()=>{const type=$('controlSelect').value;const checked=name=>document.querySelector(`input[name="${name}"]:checked`).value;
 if(type==='mode')run({type,value:checked('mmiMode'),source:'MMI'});
 if(type==='route')run(checked('routeAction')==='set'?{type:'route',id:$('mmiRoute').value,source:'MMI'}:{type:'stop',signal:$('mmiSignal').value,source:'MMI'});
 if(type==='point')run({type,id:$('mmiPoint').value,value:checked('mmiPointState'),source:'MMI'});
 if(type==='scan')run({type,scope:checked('mmiScope'),source:'MMI'});
};
$('mmiCancel').onclick=()=>{run({type:'cancel',source:'MMI'});fields();};
$('pauseBtn').onclick=()=>{paused=!paused;$('pauseBtn').textContent=paused?'▶ 계속':'Ⅱ 일시정지';};
$('skipBtn').onclick=()=>run({type:'tick',seconds:10});
$('resetBtn').onclick=()=>{if(!confirm('현재 상태와 조작 기록을 초기화할까요? 과제 달성 기록은 유지됩니다.'))return;state=C.initial();activeTask=null;paused=false;$('pauseBtn').textContent='Ⅱ 일시정지';if($('actionDialog').open){dialogAction=null;$('actionDialog').close();}fields();render();taskView();toast('새 실습 세션을 시작합니다.');};
$('startTask').onclick=startTask;
$('checkTask').onclick=()=>{if(activeTask!==taskIndex)return toast('먼저 이 과제를 시작하세요.',true);const ok=tasks[taskIndex].check(state.events.slice(taskStart));if(ok){if(!completed.includes(taskIndex))completed.push(taskIndex);try{localStorage.setItem('ctclab-completed',JSON.stringify(completed));}catch{}taskView();$('taskResult').className='complete-banner';$('taskResult').textContent='✓ 목표 조작과 최종 상태를 확인했습니다.';render();}else{$('taskResult').className='';$('taskResult').textContent='아직 필수 조작 또는 최종 상태가 충족되지 않았습니다.';}toast(ok?'과제 달성 · '+tasks[taskIndex].title:'조작 경로와 최종 상태를 다시 확인하세요.',!ok);};
$('nextTask').onclick=()=>{taskIndex=(taskIndex+1)%tasks.length;taskView();};
$('taskBody').onclick=e=>{const b=e.target.closest('[data-occupy]');if(b)run({type:'occupy',track:b.dataset.occupy,source:'훈련 조건'});};
for(const id of ['guideBtn','footerGuide','overviewBtn'])$(id).onclick=()=>$('guideDialog').showModal();$('closeGuide').onclick=()=>$('guideDialog').close();
$('fieldMenu').onclick=()=>{document.querySelector('.mmi-window').scrollIntoView({behavior:'smooth',block:'nearest'});toast('현장 제어 → 현장설비제어');};
$('systemMenu').onclick=()=>{document.querySelector('.log-panel').scrollIntoView({behavior:'smooth',block:'nearest'});toast('이 세션의 가상 조작 이력을 표시합니다.');};
$('workspaceNav').onclick=()=>window.scrollTo({top:0,behavior:'smooth'});
$('exportBtn').onclick=()=>{const blob=new Blob([JSON.stringify({app:'CTC LAB v0.1',exportedAt:new Date().toISOString(),assumptions:'훈련용 배선 / 해정 대기 30초 / 자동진로 미구현',state},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='ctc-lab-session.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('현재 상태와 조작 기록을 저장했습니다.');};
setInterval(()=>{
 if(paused||$('actionDialog').open||$('guideDialog').open)return;
 const waiting=Object.values(state.routes).some(r=>r.status==='RELEASING');
 C.dispatch(state,{type:'tick',seconds:1});
 $('clock').textContent=time(state.clock);
 // Only the waiting diagram needs a clock refresh; preserve log scroll and SVG focus otherwise.
 if(waiting){drawTracks();$('stateRoutes').textContent=Object.values(state.routes).filter(r=>r.status==='SET').length+' / '+Object.values(state.routes).filter(r=>r.status==='RELEASING').length;}
 $('stateScan').textContent=state.clock<state.scanUntil?'재수신 완료':'정상';
 $('lsStatus').textContent=state.clock<state.scanUntil?'베이스스캔 · 가상 현장 상태 재수신 완료':'우클릭으로 베이스스캔 메뉴 열기';
},1000);
fields();render();taskView();
