const assert=require('node:assert/strict');
const {initial,dispatch}=require('./core.js');
let count=0;
function test(name,fn){fn();count++;console.log('PASS',name);}
const action=(s,type,extra={})=>dispatch(s,{type,source:'test',...extra});
test('AUTO rejects manual route; CCM accepts',()=>{const s=initial();assert.equal(action(s,'route',{id:'1A-1T'}).ok,false);action(s,'mode',{value:'CCM'});assert.equal(action(s,'route',{id:'1A-1T'}).ok,true);assert.equal(s.signals['1A'],'GO');});
test('LOCAL transfer waits, rejection preserves mode, acceptance changes owner',()=>{const s=initial();action(s,'mode',{value:'LOCAL'});assert.equal(s.mode,'AUTO');assert.equal(s.pending,'LOCAL');action(s,'handover',{accept:false});assert.equal(s.mode,'AUTO');action(s,'mode',{value:'LOCAL'});action(s,'handover',{accept:true});assert.equal(s.mode,'LOCAL');assert.equal(action(s,'mode',{value:'AUTO'}).ok,false);action(s,'mode',{value:'CCM'});assert.equal(s.mode,'LOCAL');action(s,'handover',{accept:true});assert.equal(s.mode,'CCM');});
test('opposing routes and point controls reject while locked',()=>{const s=initial();s.mode='CCM';action(s,'route',{id:'1A-1T'});assert.equal(action(s,'route',{id:'3A-B070T'}).ok,false);assert.equal(action(s,'point',{id:'21',value:'R'}).ok,false);});
test('signal stop preserves lock until elapsed time reaches 30 seconds',()=>{const s=initial();s.mode='CCM';action(s,'route',{id:'1A-1T'});action(s,'stop',{signal:'1A'});assert.equal(s.signals['1A'],'STOP');action(s,'tick',{seconds:29});assert.equal(action(s,'point',{id:'21',value:'R'}).ok,false);action(s,'tick',{seconds:1});assert.deepEqual(s.routes,{});assert.equal(action(s,'point',{id:'21',value:'R'}).ok,true);});
test('cancel never changes equipment state',()=>{const s=initial();const previous=JSON.stringify({mode:s.mode,points:s.points,signals:s.signals,routes:s.routes});action(s,'cancel');assert.equal(JSON.stringify({mode:s.mode,points:s.points,signals:s.signals,routes:s.routes}),previous);});
test('scan records separate scopes without resetting route or point state',()=>{const s=initial();s.mode='CCM';action(s,'route',{id:'1A-2T'});action(s,'scan',{scope:'current'});action(s,'scan',{scope:'all'});assert.equal(s.points['21'],'R');assert.equal(s.routes['1A-2T'].status,'SET');assert.deepEqual(s.scans,{current:1,all:1});});
test('occupied track blocks route creation',()=>{const s=initial();s.mode='CCM';action(s,'occupy',{track:'1T'});assert.equal(action(s,'route',{id:'1A-1T'}).ok,false);assert.equal(s.signals['1A'],'STOP');});
test('independent routes coexist',()=>{const s=initial();s.mode='CCM';assert.equal(action(s,'route',{id:'1A-1T'}).ok,true);assert.equal(action(s,'route',{id:'2A-2T'}).ok,true);assert.equal(Object.keys(s.routes).length,2);});
console.log(`${count} state tests passed`);
