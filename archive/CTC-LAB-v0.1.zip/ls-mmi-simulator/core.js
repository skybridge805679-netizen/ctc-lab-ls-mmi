(function (root) {
  'use strict';
  const routes = {
    '1A-1T': {signal:'1A', tracks:['W1','1T'], points:{'21':'N'}},
    '1A-2T': {signal:'1A', tracks:['W1','2T'], points:{'21':'R'}},
    '2A-2T': {signal:'2A', tracks:['E2','2T'], points:{'51':'N'}},
    '2A-1T': {signal:'2A', tracks:['E2','1T'], points:{'51':'R'}},
    '3A-B070T': {signal:'3A', tracks:['1T','W1'], points:{'21':'N'}},
    '3A-B065T': {signal:'3A', tracks:['1T','W2'], points:{'21':'R'}},
    '4A-B071T': {signal:'4A', tracks:['2T','E2'], points:{'51':'N'}}
  };
  function initial() { return {mode:'AUTO', pending:null, clock:0, points:{'21':'N','51':'N'}, signals:{'1A':'STOP','2A':'STOP','3A':'STOP','4A':'STOP'}, routes:{}, occupied:[], logs:[], events:[], scans:{current:0,all:0}, scanUntil:0}; }
  function dispatch(s, a) {
    const reject = message => { s.logs.unshift({time:s.clock,source:a.source||'훈련',action:a.type,result:'거부',message}); return {ok:false,message}; };
    const done = message => { s.logs.unshift({time:s.clock,source:a.source||'훈련',action:a.type,result:'완료',message}); s.events.push({type:a.type,...a,time:s.clock}); return {ok:true,message}; };
    if(a.type==='tick') {s.clock+=a.seconds||1; for(const [id,r] of Object.entries(s.routes)) if(r.status==='RELEASING' && r.until<=s.clock) delete s.routes[id]; return {ok:true};}
    if(a.type==='cancel') return done('확인 취소 · 제어명령 전송 없음');
    if(a.type==='mode') {
      if(!['AUTO','CCM','LOCAL'].includes(a.value)) return reject('유효하지 않은 제어모드입니다.');
      if(s.pending) return reject('진행 중인 제어권 인계 응답을 먼저 처리하세요.');
      if(s.mode===a.value) return reject('이미 '+a.value+' 모드입니다.');
      if(a.value==='AUTO' && s.mode!=='CCM') return reject('AUTO 전환은 CCM 모드에서만 가능합니다.');
      if(a.value==='LOCAL' || s.mode==='LOCAL') {s.pending=a.value; return done(a.value+' 전환 요청 · 현장 응답 대기');}
      s.mode=a.value; return done(a.value+' 전환 완료');
    }
    if(a.type==='handover') {
      if(!s.pending) return reject('진행 중인 제어권 인계가 없습니다.');
      const target=s.pending; s.pending=null;
      if(a.accept) {s.mode=target;return done('현장 인계 수락 · '+target+' 전환 완료');}
      return done('현장 인계 거절 · 기존 '+s.mode+' 유지');
    }
    if(a.type==='scan') { if(!['current','all'].includes(a.scope)) return reject('베이스스캔 범위를 선택하세요.'); s.scans[a.scope]++;s.scanUntil=s.clock+3;return done((a.scope==='all'?'전체 제어역':'현재역')+' 베이스스캔 · 가상 현장 상태 재수신'); }
    if(['route','stop','point'].includes(a.type) && (s.mode!=='CCM'||s.pending)) return reject('CCM 모드와 관제실 제어권을 확인하세요.');
    if(a.type==='route') {
      const config=routes[a.id];if(!config) return reject('진로를 선택하세요.');
      if(s.routes[a.id]) return reject('이미 설정되었거나 해정 대기 중인 진로입니다.');
      if(config.tracks.some(t=>s.occupied.includes(t))) return reject('진로에 점유 궤도가 있습니다.');
      for(const [id,r] of Object.entries(s.routes)) {
        const c=routes[id]; if(config.signal===c.signal || config.tracks.some(t=>c.tracks.includes(t)) || Object.keys(config.points).some(p=>p in c.points)) return reject(id+' 진로와 경합하거나 공통 전환기가 쇄정 중입니다.');
      }
      Object.assign(s.points,config.points);s.routes[a.id]={status:'SET',until:null};s.signals[config.signal]='GO'; return done(a.id+' 진로 설정 · 신호 진행');
    }
    if(a.type==='stop') {
      if(!(a.signal in s.signals)) return reject('신호기를 선택하세요.');
      const entries=Object.entries(s.routes).filter(([id,r])=>routes[id].signal===a.signal && r.status==='SET');
      if(!entries.length) return reject('설정된 진로가 없습니다.');
      s.signals[a.signal]='STOP';
      for(const [,r] of entries) {r.status='RELEASING';r.until=s.clock+30;}
      return done(a.signal+' 신호 정지 · 훈련용 해정 대기 30초');
    }
    if(a.type==='point') {
      if(!(a.id in s.points)||!['N','R'].includes(a.value)) return reject('전환기와 정·반위를 선택하세요.');
      if(Object.keys(s.routes).some(id=>a.id in routes[id].points)) return reject(a.id+' 전환기가 진로에 쇄정되어 있습니다.');
      if(s.occupied.length) return reject('이 훈련 모형은 궤도 점유 시 전환기 제어를 제한합니다.');
      s.points[a.id]=a.value;return done(a.id+' 전환기 '+(a.value==='N'?'정위':'반위')+' 확인');
    }
    if(a.type==='occupy') { if(!['W1','W2','1T','2T','E2'].includes(a.track)) return reject('유효하지 않은 궤도입니다.');s.occupied=s.occupied.includes(a.track)?s.occupied.filter(t=>t!==a.track):[...s.occupied,a.track];return done(a.track+' 점유 상태 변경'); }
    return reject('지원하지 않는 조작입니다.');
  }
  const api={initial,dispatch,routes}; if(typeof module!=='undefined') module.exports=api; else root.SimCore=api;
})(typeof window!=='undefined'?window:globalThis);
